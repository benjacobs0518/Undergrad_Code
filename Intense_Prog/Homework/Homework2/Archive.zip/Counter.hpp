#include <vector>
#include <string>
#include <map>
#include <set>
#include "iostream"

template <class T>
class Counter{
  public:
    Counter(){total_count=0;}
    Counter(std::vector<T> vals){
      total_count=0;
      for(int i=0; i<vals.size(); i++){
        mapV[vals[i]] += 1;
        total_count += 1;
      }
      printMap();
    };

    int Count(){return total_count;}
    int Count(T key){
      if(mapV.find(key) != mapV.end()){
        typename std::map<T, int>::iterator it;
        for(it = mapV.begin(); it != mapV.end(); it++){
          if(it->first==key){
            return it->second;
          }
        }
      }
      return -1;
    }

    int Count(T min, T max){
      int temp_total=0;

      typename std::map<T, int>::iterator it;
      for(it = mapV.begin(); it != mapV.end(); it++){
        if((it->second >= min) && (it->second < max)){
          temp_total += it->second;
        }
      }
      return temp_total;
    }

    void printMap(){
      for (std::pair<T, int> pair : mapV) {
      std::cout << pair.first << " : " << pair.second << std::endl;
      }
    }

    void Remove(T key){
      mapV.erase(mapV.find(key));
      printMap();
    }

    void Increment(T key){
      if(mapV.find(key) != mapV.end()){
        typename std::map<T, int>::iterator it;
        for(it = mapV.begin(); it != mapV.end(); it++){
          if(it->first==key){
            it->second = it->second+1;
            total_count = total_count+1;
          }
        }
      }
    }

    void Increment(T key, int n){
      if(mapV.find(key) != mapV.end()){
        typename std::map<T, int>::iterator it;
        for(it = mapV.begin(); it != mapV.end(); it++){
          if(it->first==key){
            it->second = it->second+n;
            total_count = total_count+n;
          }
        }
      }
    }

    void Decrement(T key){
      if(mapV.find(key) != mapV.end()){
        typename std::map<T, int>::iterator it;
        for(it = mapV.begin(); it != mapV.end(); it++){
          if(it->first==key){
            if(it->second > 1){
              it->second = it->second-1;
              total_count = total_count-1;
            }
          }
        }
      }
    }

    void Decrement(T key, int n){
      if(mapV.find(key) != mapV.end()){
        typename std::map<T, int>::iterator it;
        for(it = mapV.begin(); it != mapV.end(); it++){
          if(it->first==key ){
            if(it->second - n > 0){
              it->second = it->second-n;
              total_count = total_count-n;
            }
          }
        }
      }
    }

    T MostCommon(){
      if(!mapV.empty()){
        std::pair<T, int> temp;
        for (std::pair<T, int> pair : mapV) {
          if(pair.second > temp.second)
          {
            temp = pair;
          }
        }
        return temp.first;
      }
      else{
          std::domain_error("Error, empty counter map");
          return 0;
      }
    }

    std::vector<T> MostCommon(int n){
      std::map<T,int> temp;
      std::vector<T> sol;
      for(std::pair<T, int> pair : mapV){
          temp.insert(pair);
      }

      for(int i = 0; i<n; i++){
        std::pair<T, int> temp_max;
        for (std::pair<T, int> pair : temp){
          if(pair.second > temp_max.second)
          {
            temp_max = pair;
          }
        }
        sol.push_back(temp_max.first);
        temp.erase(temp.find(temp_max.first));
      }
      return sol;
    }

    T LeastCommon() const{
      if(!mapV.empty()){
        std::pair<T, int> temp;
        for (std::pair<T, int> pair : mapV) {
          if(temp.second == 0){
            temp = pair;
          }
          else{
            if(pair.second < temp.second)
            {
              temp = pair;
            }
          }
        }
        std::cout<<"Least Common "<<temp.first << ":"<< temp.second<<std::endl;
        return temp.first;
      }
      else{
          std::domain_error("Error, empty counter map");
          return 0;
      }
    }

    std::vector<T> LeastCommon(int n){
      std::map<T,int> temp;
      std::vector<T> sol;
      for(std::pair<T, int> pair : mapV){
          temp.insert(pair);
      }

      for(int i = 0; i<n; i++){
        std::pair<T, int> temp_min;
        for (std::pair<T, int> pair : temp){
          if(temp_min.second == 0){
            temp_min = pair;
          }
          else{
            if(pair.second < temp_min.second)
            {
              temp_min = pair;
            }
          }
        }
        sol.push_back(temp_min.first);
        temp.erase(temp.find(temp_min.first));
      }
      return sol;
    }

    std::map<T,double> Normalized(){
      std::map<T,double> sol;
      std::pair<T,double> temp;
      for(std::pair<T, int> pair : mapV){
          temp.first = pair.first;
          temp.second = (double)pair.second/(double)total_count;
          sol.insert(temp);
      }
      return sol;
    }

    std::set<T> Keys(){
      std::set<T> sol;
      for(std::pair<T, int> pair : mapV){
        sol.insert(pair.first);
      }
      return sol;
    }

    std::vector<int> Values(){
      std::vector<int> sol;
      for(std::pair<T, int> pair : mapV){
        sol.insert(pair.second);
      }
      return sol;
    }

    template <typename U>
    friend std::ostream& operator<<(std::ostream& os, const Counter<U> &n){
      std::map<U,int> temp = n.mapV;
      typename std::map<U, int>::iterator it;
      for(it = temp.begin(); it != temp.end(); it++){
      os << it->first << " : " << it->second << std::endl;
      }
      return os;
    }


  private:
    std::map<T,int> mapV;
    int total_count;
};
