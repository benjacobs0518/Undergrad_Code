#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include <vector>
#include "Counter.hpp"
#include "iostream"

using namespace std;

vector<string> s = {"cat", "dog", "mouse", "rat", "cat", "dog"};
Counter<string> a(s);

vector<int> i = {1,2,2,3,3,3,4,5,5,5};
Counter<int> b(i);

TEST_CASE("Constructors"){
  SECTION("Empty") {
  Counter<int> z;
  REQUIRE(z.Count() == 0);
  }

  SECTION("Pre set values") {
  REQUIRE(b.Count() == 10);
  }
}

TEST_CASE("Count"){
  SECTION("Count()") {
  REQUIRE(a.Count() == 6);
  }

  SECTION("Count(key)") {
  REQUIRE(b.Count(2) == 2);
  }

  SECTION("Count(min, max)") {
  REQUIRE(b.Count(1,3) == 4);
  }

}

TEST_CASE("Remove"){
  SECTION("Remove(T key)") {
    b.Remove(3);
  REQUIRE(b.Count(3) == -1);
  }
}

TEST_CASE("Incriment"){
  SECTION("Incriment T key") {
    b.Increment(1);
  REQUIRE(b.Count(1) == 2);
  }

  SECTION("Incriment T key int n") {
    b.Increment(4,3);
  REQUIRE(b.Count(4) == 4);
  }

}

TEST_CASE("Decrement"){
  SECTION("Decrement T key") {
    b.Decrement(5);
  REQUIRE(b.Count(5) == 2);
  }

  SECTION("Decrement T key int n") {
    b.Decrement(4,1);
  REQUIRE(b.Count(4) == 3);
  }

}

TEST_CASE("MostCommon"){
  SECTION("MostCommon() int") {
    int test = b.MostCommon();
  REQUIRE(test == 4);
  }

  SECTION("MostCommon int n") {
    b.Increment(4,100);
    b.Increment(3,50);
    std::vector<int> temp1 = b.MostCommon(3);
  REQUIRE(temp1[0] == 4);
  }

}

TEST_CASE("LeastCommon"){
  SECTION("LeastCommon() int") {
    int test = b.LeastCommon();
  REQUIRE(test == 1);
  }

  SECTION("LeastCommon int n") {
    std::vector<int> temp7 = b.LeastCommon(3);
  REQUIRE(temp7[1] == 2);
  }

}

TEST_CASE("Normalized"){
  SECTION("Normalized()") {
    vector<int> i1 = {1,2,3,4};
    Counter<int> b1(i1);
    b1.Increment(1,9);
    b1.Increment(2,19);
    b1.Increment(3,29);
    b1.Increment(4,39);
    b1.printMap();

    std::map<int,double> temp1 = b1.Normalized();
    std::pair<int, double> temp2;
    for (std::pair<int, double> pair : temp1) {
      if(temp2.second == 0.0){
        temp2 = pair;
      }
    std::cout << pair.first << " : " << pair.second << std::endl;
    }
  REQUIRE(temp2.second == 0.1);
  }

}

TEST_CASE("Keys"){
  SECTION("Keys") {
    vector<int> i1 = {1,2,3,4};
    Counter<int> b1(i1);
    std::set<int> temp1 = b1.Keys();
    std::set<int>::iterator it;
    for (it=temp1.begin(); it!=temp1.end(); it++){
      std::cout<< *it << std::endl;
    }
  REQUIRE(it == 4);
  }

}
