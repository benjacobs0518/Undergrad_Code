#include "rules.h"

Rules::Rules()
{

}
