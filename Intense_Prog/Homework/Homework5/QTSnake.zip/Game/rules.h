#ifndef RULES_H
#define RULES_H


class Rules
{
public:
    Rules();
};

#endif // RULES_H
