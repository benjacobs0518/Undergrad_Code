#include <iostream>
#include <math.h>
#include "Point.h"
using namespace std;

Point::Point(){ //Instantate point with origin coordinates
  x = 0; //sets x to 0
  y = 0;//sets y to 0
}

Point::Point(int newx, int newy){ //Instantate point with new coordinates
  x = newx; //sets x to newx
  y = newy;//sets y to newy
}


float Point::Distance(Point p){ //distance function
  int diffx = abs(p.x - x); //calculates the distance for x
  int diffy = abs(p.y - y); //calculates the distance for y
  return sqrt(pow(diffx,2) + pow(diffy,2)); //calculates the euclidean distance
}

void Point::Translate(int off){ // translate function
  std::cout<<"Original coordinates x:"<< x << " y: " << y << std::endl;
  x += off; // change x value by offset value 'off'
  y += off;// change y value by offset value 'off'
  std::cout<<"Shifted by: "<< off << std::endl;
  std::cout<<"New coordinates x: "<< x << " y: " << y << std::endl;
}
