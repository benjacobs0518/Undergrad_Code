#include <iostream>
#include "Point.h"

void PrintCoord(Point p){ //Prints the basic coordinates of the point to test
    std::cout <<  "x: " << p.get_x() << " y: " << p.get_y() << std::endl;
}

void PrintDist(Point a, Point b){ //prints the distance between two sets of coordinates using the distance function
    std::cout <<  "Distance from " << a.Distance(b) << std::endl;
    std::cout <<  "Distance from " << b.Distance(a) << std::endl;
}


int main(){ //main function
  Point test; //test Point for origin coordinates
  Point a(1,2); //instantiated point a at 1,2
  Point b(-2,-4);//instantiated point b at -2,-4
  PrintCoord(a); //print coord
  PrintCoord(b); //print coord
  PrintCoord(test); //print coord
  PrintDist(a,b); //print distance inbetween points a and b

  a.Translate(-5); //mutate a's disance by -5
  b.Translate(8); //mutate b's disance by -5

}
