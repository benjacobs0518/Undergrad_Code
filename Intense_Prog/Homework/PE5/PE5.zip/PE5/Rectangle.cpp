/**
Creator: Joshua Rymkiewicz
Worked On: Ben Jacobs

PE5
**/

#include <iostream>
#include "Rectangle.h"

Rectangle::Rectangle(Point p1, Point p2) {
    if (p1.x >= p2.x || p1.y >= p2.y) {
    std::cout << "Negative Points. Unable to create rectangle" << std::endl;

    Point temp = {.x=p1.x, .y=p1.y};
    Point newp1 = {.x=p2.x, .y=p2.y};
    Point newp2 = {.x=temp.x, .y=temp.y };

    p1_ = newp1;
    p2_ = newp2;
  //  exit(0);
  }
  else {
    p1_ = p1;
    p2_ = p2;
  }
}

int Rectangle::GetWidth() {
  return p2_.x - p1_.x;
}

int Rectangle::GetHeight() {
  return p2_.y - p1_.y;
}

bool Rectangle::Overlaps(Rectangle& other) {
  if((other.p1_.x == p1_.x) || (other.p2_.x == p2_.x)){
    return true;
  }
  else if((other.p1_.x == p1_.x) || (other.p2_.y == p2_.y)){
    return true;
  }
  else
  {
    return false;
  }
}

int Rectangle::CalculateArea() {
  return Rectangle::GetWidth() * Rectangle::GetHeight();
}

void Rectangle::Expand() {
  p1_ = { .x= p1_.x - 1, .y= p1_.y - 1 };
  p2_ = { .x= p2_.x + 1, .y= p2_.y + 1 };
}

void Rectangle::Shrink() {
  p1_ = { .x= p1_.x + 1, .y= p1_.y + 1 };
  p2_ = { .x= p2_.x - 1, .y= p2_.y - 1 };
}

/*
Bugs Found:
Shrink - does not properly modify point1 coordinates
*/
